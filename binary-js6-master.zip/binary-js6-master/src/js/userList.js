var _ = require('lodash');
require('../img/avatar3.png');

function userList(users){
    const container = document.getElementById('root');
    const image = document.createElement('img');
    image.src = 'dist/' + require('../img/avatar3.png');
    const sortedUsers = _.sortBy(users, 'age');
    this.showList = () => {
        sortedUsers.forEach((user) => {
            const div = document.createElement("div");
            div.append(user.name + ' ' + user.age);
            container.appendChild(div);
            container.appendChild(image);
        });
    };
}

module.exports = userList;