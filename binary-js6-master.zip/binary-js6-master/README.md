Academy 17: WebPack, modularity. Александр Ковалев. JS - 06.2
