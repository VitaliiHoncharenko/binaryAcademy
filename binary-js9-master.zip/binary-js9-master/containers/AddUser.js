import React from 'react'
import { connect } from 'react-redux'
import { addUser } from '../actions'

let AddUser = ({ dispatch }) => {
  let input

  return (
    <div>
        <form
            className="form"
            onSubmit={e => {
              e.preventDefault()
              if (!input.value.trim()) {
                return
              }
              dispatch(addUser(input.value))
              input.value = ''
            }}
      >
        <input
            className="input"
            ref={node => {
                input = node
            }}
        />
        <button className="button" type="submit">
          Add User
        </button>
      </form>
    </div>
  )
}
AddUser = connect()(AddUser)

export default AddUser