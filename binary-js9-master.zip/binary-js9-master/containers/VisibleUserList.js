import { connect } from 'react-redux'
import { deleteUser } from '../actions'
import UserList from '../components/UserList'

const getVisibleUsers = (users, filter) => {
    return users
}

const mapStateToProps = state => {
  return {
    users: getVisibleUsers(state.users, state.visibilityFilter)
  }
}

const mapDispatchToProps = dispatch => {
  return {
    onUserClick: id => {
      dispatch(deleteUser(id))
    }
  }
}

const VisibleUserList = connect(
  mapStateToProps,
  mapDispatchToProps
)(UserList)

export default VisibleUserList