let nextUserId = 0
export const addUser = text => {
  return {
    type: 'ADD_USER',
    id: nextUserId++,
    text
  }
}

export const setVisibilityFilter = filter => {
  return {
    type: 'SET_VISIBILITY_FILTER',
    filter
  }
}

export const deleteUser = id => {
  return {
    type: 'DELETE_USER',
    id
  }
}