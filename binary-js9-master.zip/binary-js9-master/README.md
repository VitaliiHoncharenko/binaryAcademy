# Academy 2017: React_part 2. Александр Ковалев JS-9
