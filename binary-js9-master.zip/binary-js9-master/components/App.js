import React from 'react'
import AddUser from '../containers/AddUser'
import VisibleUserList from '../containers/VisibleUserList'

const App = () => (
  <div className="main">
    <AddUser />
    <VisibleUserList />
  </div>
)

export default App