import {ImprovedFighter, ImprovedFighterInterface} from './improvedFighter';
import Fighter, {FighterInterface} from './fighter';

interface FightInterface {
    fighter: FighterInterface;
    improvedFighter: ImprovedFighterInterface;
    Fight: () => void;
}

const random = (point: number[]) => Math.floor(Math.random() * point.length );
const arena = document.getElementById('arena');


export const Fight = function (fighter: FighterInterface, improvedFighter: ImprovedFighterInterface, ...point) {
    while(true) {
        if(fighter.health > 0) {
            fighter.hit(improvedFighter, point[random(point)]);
        } else {
            const improvedWin = document.createElement('div');
            improvedWin.className = "improved-fighter";
            improvedWin.innerHTML = `${improvedFighter.name} is winner!`;
            arena.appendChild(improvedWin);
            break;
        }
        if(improvedFighter.health > 0) {
            improvedFighter.doubleHit(fighter, point[random(point)]);
        } else {
            const fighterWin = document.createElement('div');
            fighterWin.className = "simple-fighter";
            fighterWin.innerHTML = `${fighter.name} is winner!`;
            arena.appendChild(fighterWin);
            break;
        }
    }
}