const arena = document.getElementById('arena');

export interface FighterInterface {
    health: number;
    power: number;
    name: string;
    setDamage: (damage: number) => void;
    hit: (enemy: FighterInterface, point: number) => void;
}

export default class Fighter implements FighterInterface {
    name: string;
    power: number;
    health: number;
    constructor(name: string ='boxer', power: number = 1, health: number = 100) {
        this.name = name;
        this.power = power;
        this.health = health;
    }

    setDamage(damage: number){
        (this.health -= damage) > 0 ? this.health : this.health = 0;
        const damageElem = document.createElement('div');
        damageElem.className = "damage";
        damageElem.innerHTML = `${this.name} - hp left: ${this.health}`;
        arena.appendChild(damageElem);
    }

    hit(enemy: FighterInterface, point: number){
        enemy.setDamage(point * this.power);
    }
}