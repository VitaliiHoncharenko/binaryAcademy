import Fighter, {FighterInterface} from './fight/fighter'
import {Fight} from './fight/fight'
import {ImprovedFighter} from './fight/improvedFighter'


let fighter = new Fighter('Fury', 3, 250);
let improvedFighter = new ImprovedFighter('KLichko', 3, 250);

Fight(fighter, improvedFighter, 22, 3, 45, 34);
