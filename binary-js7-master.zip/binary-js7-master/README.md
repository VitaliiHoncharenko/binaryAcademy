# Academy 17: TypeScript. Роман Саган JS-07
