## Academy 2017: React-part 1. Александр Ковалев JS-08
