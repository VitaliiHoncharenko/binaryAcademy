import React from 'react';

const AddUser = (props) => {
        return (
            <div>
                <form className="form">
                    <input className="input" value={props.term} onChange={props.onChange} />
                    <button className="button" onClick={props.onAddUser}>Submit</button>
                </form>
            </div>
        )
}

export default AddUser