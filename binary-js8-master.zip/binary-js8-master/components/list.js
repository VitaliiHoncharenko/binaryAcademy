import React, {Component} from 'react';
import User from './user';

const List = (props) => {
        if (props.list.length) {
            return (
                <ol className="list">
                    {
                        props.list.map (
                            (elem, index) => {
                                return (
                                    <User
                                        key={elem.id}
                                        onRemoveItem={props.onRemoveItem}
                                        user={elem.user}
                                    />
                                )
                            }
                        )
                    }
                </ol>
            )
        }
    return null
}

export default List;