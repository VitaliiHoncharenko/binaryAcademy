import React, { Component } from 'react';
import List from './list';
import AddUser from './addUser';


export default class App extends Component {
    constructor(props) {
        super(props)

        this.state = {term: '', list: []}
        this.onChange = this.onChange.bind(this)
        this.onAddUser = this.onAddUser.bind(this)
    }

    shouldComponentUpdate(nextProps, nextState) {
        return nextProps.term != nextState.term
    }

    createUniqueID() {
        return 'id-' + Math.random().toString(36).substr(2, 16)
    }

    onChange(event){
        this.setState({term: event.target.value})
    }

    onAddUser(event) {
        event.preventDefault()
        let list = this.state.list;
        let term = this.state.term;
        let isPresent = false;

        if (term != '') {
            let list = this.state.list

            for (let i = 0; i < list.length; i++) {
                if(list[i].user == term) {
                    isPresent = true
                    break
                }
            }
            if(!isPresent) {
                this.state.list.push({
                    id: this.createUniqueID(),
                    user: term
                })
                this.setState({term: '', list: this.state.list})
            } else {
                alert('We already have this one!')
            }
        } else {
            alert('Try to type something!')
        }

    }

    onRemoveItem(event) {
        const list = this.state.list
        const removedItem = event.target.parentElement.querySelector('b').innerText

        let index = this.state.list.indexOf(event.target.parentElement.querySelector('b').innerText)
        for(let i = 0; i < list.length; i++) {
            if(list[i].user == removedItem) {
                delete this.state.list.splice(0, 1);
                break
            }
        }
        this.setState({list: this.state.list})

    }

    render() {
        return (
            <div className="main">
                <AddUser
                    term={this.state.term}
                    onChange={this.onChange}
                    onAddUser={this.onAddUser}
                />
                <List
                    list={this.state.list}
                    onRemoveItem={(event) => this.onRemoveItem(event)}
                />
            </div>
        );
    }
}
