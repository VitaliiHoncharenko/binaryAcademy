import React, {Component} from 'react';

const User = (props) => {
    return (
        <li>
            <b>{props.user}</b>
            <span onClick={props.onRemoveItem}>X</span>
        </li>
    )
}

export default User